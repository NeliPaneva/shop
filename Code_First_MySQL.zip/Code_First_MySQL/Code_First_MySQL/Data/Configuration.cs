﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Code_First_MySQL.Data
{
   public static class Configuration
    {
        public const string cs = "server=localhost;database=shop;username=root;password=123qwe!@#QWE";

    }
}
