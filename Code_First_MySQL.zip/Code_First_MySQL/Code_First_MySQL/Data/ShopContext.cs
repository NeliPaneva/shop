﻿using Code_First_MySQL.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Code_First_MySQL.Data
{
    public class ShopContext:DbContext
    {
        public ShopContext()
        {
                
       
        }
        public ShopContext(DbContextOptions options):base(options)
        {
                
        }
        public DbSet<Product> Products { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
                optionsBuilder.UseMySql(Configuration.cs);
            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {  //moje da se definirat ogranichenia za poletata
           // modelBuilder.Entity<Product>().HasKey...
            base.OnModelCreating(modelBuilder);
        }
    }
}
