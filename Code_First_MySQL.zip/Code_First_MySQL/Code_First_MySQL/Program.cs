﻿using Code_First_MySQL.Views;
using System;

namespace Code_First_MySQL
{
    class Program
    {
        static void Main(string[] args)
        {
            var display= new Display();
        }
    }
}
