﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;

namespace ShopAssistant.Data
{
    public class Configuration
    {
        public const string connectionString = "server=localhost;database=shop;username=root;password=123qwe!@#QWE";
    }
}
