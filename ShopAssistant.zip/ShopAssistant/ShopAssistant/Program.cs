﻿using ShopAssistant.Presentation;
using System;

namespace ShopAssistant
{
    class Program
    {
        static void Main(string[] args)
        {
            var display = new Display();
        }
    }
}
